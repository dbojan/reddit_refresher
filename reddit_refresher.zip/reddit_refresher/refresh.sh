
#check for new posts on reddit, post list to ntfs.sh/enter_name_here
#uses grep, curl, sed

#note that nsfw posts will not be displayed for aonymous users, without login
#2025-08-24-2

#remember to chmod 755 ./refresh.sh if you upload it to your server

#add to crontab as user: crontab -e
#set it to check for new posts every 2 minutes
#to use nano editor, also add to /etc/rc.local: export EDITOR=nano
#for 5 min, replace with */2 with */5, for 1 min replace with */2 with *
#edited
# */2 * * * * /mnt/wd1TB/ftp/working_on/reddit_refresher/refresh.sh


#functions:

fn_send() {
	curl --data-binary @"$1" "$chan"
}

#test if tools exist
for c in curl sed grep
do
	if ! command -v $c >/dev/null
	then
		echo $c is missing
	fi
done

#remove to have it running in loop
#while true; do

#-e enable newline interpretation
#-n do not print newline
echo -e "\nstart at $(date +%Y_%m_%d-%H:%M:%S) ... "

#change to script dir
cd "${0%/*}"

ramdisk=/ramdisk/
ramdisk=''

#use folder /ramdisk/ for files path if it exists
if ! [ -d "$ramdisk" ]; then
	#echo ramdisk "$ramdisk" folder is missing
	ramdisk=''
fi

file_new="${ramdisk}r_reddit_links_only_without_offer-new.txt"
file_old="${ramdisk}r_reddit_links_only_without_offer-old.txt"
file_difference="${ramdisk}r_difference-filenew-minus-fileold.txt"
#edited
chan="https://ntfy.sh/gamesr"
#edited
user_agent="reddit-refresher-github"
url="https://old.reddit.com/user/dbojan76/m/games/new/"
wait_time=120


#echo "path to ramdisk: $ramdisk"
#echo "file_new: $file_new"


#-s=silent
#-o=show only matching, -P perl regexp
#extract post titles; for single op use: curl ... url > output, 2: grep .. pattern ... input > output, 3: sed -e pattern > output (use -i for inline replace, no need her cause output to file)
#remove lines with unwanted tags
#and replace /r with https://reddit.com/r
#1. download file, 2. extract links, 3. remove unwanted tags and replace /r with https... , 4. output to file
echo "download and filter ..."
curl -s -A "$user_agent" "$url" |    grep -o -P 'data-permalink=".?\K[^"]*'     |    sed -e '/\/GiftofGames.*\/request/d' -e '/\/GiftofGames.*\/gog.*thank/d' -e '/\/GiftofGames.*\/discussion/d' -e '/\/GiftofGames.*\/intro/d' -e '/\/humblebundles.*\/review/d' -e 's/^r/https:\/\/reddit.com\/r/g'     > "$file_new"



#no file 2
if [ ! -f "$file_old" ]; then
	 echo "no old file, send new file with links ..."
	 fn_send "$file_new"
else
	#remove file, don't show error if it does not exist
	echo "check for difference ..."
	rm -f "$file_difference"
	#find difference:
	#display text in new,that is not in old
	#grep requires arguments to be in the order: first old, THEN new
	text_difference=$(grep -F -x -v -f "$file_old" "$file_new")

	if [ "$text_difference" ]; then
		echo "$text_difference" >"$file_difference"
		echo "new posts exist, send difference list ..."
		fn_send "$file_difference"
	else
		echo "no changes ..."
	fi

fi

#move current page to old, compare later
mv "$file_new" "$file_old"

#remove to have it running in loop, enable either one of those
#echo "wait for $wait_time seconds ...";           sleep $wait_time;                                                              done
#echo "wait for $wait_time seconds ...";           for v in $(seq 1 $wait_time); do echo -n "$v "; sleep 1; done;                 done
