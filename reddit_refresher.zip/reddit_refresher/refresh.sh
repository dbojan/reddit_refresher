
#check for new posts on reddit, post list to ntfs.sh/enter_name_here
#uses grep, curl, sed

#note that nsfw posts will not be displayed for aonymous users, without login
#2025-08-07-1

#remember to chmod 755 ./refresh.sh if you upload it to your server

#every 2 minutes
#add to crontab as user: crontab -e
#to use nano editor, also add to /etc/rc.local: export EDITOR=nano
# for 5 min, replace with */2 with */5, for 1 min replace with */2 with *
#edited
# */2 * * * * /path_to_folder/reddit_refresher/refresh.sh


#functions:

fn_send() {
	curl --data-binary @"$1" "$chan"
}


#change to script dir
cd "${0%/*}"

ramdisk=/ramdisk/

#use folder /ramdisk/ for files path if it exists
if ! [ -d "$ramdisk" ]; then
 echo "$ramdisk" folder is missing
 ramdisk=''
fi

file_new="${ramdisk}r_reddit_links_only_without_offer-new.txt"
file_old="${ramdisk}r_reddit_links_only_without_offer-old.txt"
dl="${ramdisk}r_downloaded_file.txt"
file_difference="${ramdisk}r_difference-filenew-minus-fileold.txt"
#edited
chan="https://ntfy.sh/gamesr"
#edited
user_agent="reddit-refresher-github"
url="https://old.reddit.com/user/dbojan76/m/games/new/"


echo "path to ramdisk: $ramdisk"
echo "file_new: $file_new"


rm "$dl"
#dl page
curl -A "$user_agent" "$url" > "$dl"

#extract post titles
#grep -oP '<a class="title may-blank " data-event-action="title" href=".?\K[^"]*/' "$dl" > "$file_new"
grep -oP 'data-permalink=".?\K[^"]*' "$dl" > "$file_new"


#remove unwanted tags
#sed -i -e '/request/d' -e '/gog/d' -e '/discussion/d' -e '/review/d'  "$file_new"
#use with / at the beginning of the string
#remove lines with \/request (or for humans: /request)
#gog is for gift of games, not gog company
#NO: data-permalink="/r/GiftofGames/comments/1mhnwbb/gog_thank_you_ucommiexander_for_stray_gods_orpheus/" 
#YES: data-permalink="/r/GameDeals/comments/1mf35eo/gog_freedom_to_buy_games_bundle_agony_agony/"
#and replace /r with https://reddit.com/r
sed -i -e '/\/request/d' -e '/\/gog_thank/d' -e '/\/gogthank/d' -e '/\/gog_a_big_thank_you/d' -e '/\/discussion/d' -e '/\/review/d' -e 's/^r/https:\/\/reddit.com\/r/g' "$file_new"


#no file 2
if [ ! -f "$file_old" ]; then
	 echo "no old file, sending new file with links"
	 fn_send "$file_new"
else
	rm "$file_difference"
	#display text in new,that is not in old
	#first old, THEN new
	text_difference=$(grep -F -x -v -f "$file_old" "$file_new")

	if [ "$text_difference" ]; then
		echo "$text_difference" >"$file_difference"
		echo "new posts exist, sending difference list ..."
		fn_send "$file_difference"
	else
		echo "no changes ..."
	fi

fi

#move current page to old, compare later
mv "$file_new" "$file_old"
